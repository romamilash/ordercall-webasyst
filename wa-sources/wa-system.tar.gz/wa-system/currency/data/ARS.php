<?php

return array(
    'code' => 'ARS',
    'sign' => '$',
	'iso4217' => '32',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Argentine peso',
    'name' => array(
        array('peso', 'pesos'),
    ),
    'frac_name' => array(
        array('centavo', 'centavos'),
    )
);